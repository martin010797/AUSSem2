package Tests;

import Structure.BST23Node;

public class TestData2 extends BST23Node<TestKey, TestingData2> {
    public TestData2(TestKey pData1, TestingData2 pValue1){
        super(pData1,pValue1);
    }
    public TestData2(TestKey pData1) {
        super(pData1);
    }
}
