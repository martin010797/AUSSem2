package Tests;

import Structure.BST23Node;

public class TestData extends BST23Node<TestKey, TestingObjectValue> {

    public TestData(TestKey pData1, TestingObjectValue pValue1) {
        super(pData1, pValue1);
    }
    public TestData(TestKey pData1) {
        super(pData1);
    }
}
