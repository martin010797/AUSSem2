package Models;

import Structure.BST23Node;

public class RegionSickCountData extends BST23Node<RegionSickCountKey, Address> {
    public RegionSickCountData(RegionSickCountKey key, Address address){
        super(key,address);
    }
}
