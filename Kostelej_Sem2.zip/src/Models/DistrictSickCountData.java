package Models;

import Structure.BST23Node;

public class DistrictSickCountData extends BST23Node<DistrictSickCountKey, Address> {
    public DistrictSickCountData(DistrictSickCountKey key, Address address){
        super(key,address);
    }
}
