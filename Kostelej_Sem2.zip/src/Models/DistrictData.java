package Models;

import Structure.BST23Node;

public class DistrictData extends BST23Node<DistrictKey, Address> {

    public DistrictData(DistrictKey key, Address address){
        super(key,address);
    }
}
