package Structure;

public interface IData<T> extends IRecord<T> {
    public T createClass();
}
